//
//  NewViewController.m
//  BlockDemo
//
//  Created by songjc on 17/1/13.
//  Copyright © 2017年 Don9. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()

@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

    self.block(666);
}


@end
