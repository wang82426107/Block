//
//  ViewController.m
//  BlockDemo
//
//  Created by songjc on 17/1/13.
//  Copyright © 2017年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "NewViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}


- (IBAction)pushAction:(id)sender {
    
    NewViewController *newVC = [[NewViewController alloc]init];
    
    newVC.block = ^(int number){
    
       printf("value = %d",number);
    };
    
    [self.navigationController pushViewController:newVC animated:YES];
    
}



@end
