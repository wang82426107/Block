//
//  NewViewController.h
//  BlockDemo
//
//  Created by songjc on 17/1/13.
//  Copyright © 2017年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^Block)(int);
@interface NewViewController : UIViewController

@property(nonatomic,assign)Block block;
@end
